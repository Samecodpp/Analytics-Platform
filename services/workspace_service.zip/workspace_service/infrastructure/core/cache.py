# TODO Implement redis cache after all busines logics

